@echo off
cd /d "%~dp0"
echo Reinstalling packages for mikuresekai with the same Python that runs main.py...
if exist vendor rmdir /s /q vendor
python -m pip uninstall -y rg-converters
python -m pip install -U -r requirements.txt
python -c "import rg_converters.converters, sys; print('rg_converters OK:', rg_converters.__file__)"
echo.
echo If the line above shows an error, send it. Otherwise run: python main.py
pause
