"""Game-look preview renderer built from the sprites MikuMikuWorld ships (preview_assets/).

Everything is composed with Pillow into one RGBA frame: stage and highway, jacket windows and
side panels, the real note / flick-arrow / hold-diamond sprites, combo digits, hit effects and
a score / life HUD. Personal use only (the sprites come from the game).
"""
from __future__ import annotations

import bisect
import json
import os
import random

from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageOps

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "preview_assets")

W, H = 1024, 588            # half of the 2048x1176 stage image
CX = W / 2
Y_J = 400.5                 # y of the judgement strip centre
HW = 0.883                  # lane half-width per pixel of y (the highway apex is at y = 0)
K_DEPTH = 10.0              # perspective strength
FALL_BASE = 650.0           # fall time in seconds = FALL_BASE / speed
LANES = 12
NOTE_F0 = 0.34              # sprite scale of a note at the judgement line
PAUSE_BOX = (W - 62, 12, W - 14, 60)

HIT_RGB = {"tap": (150, 240, 255), "critical": (255, 224, 110), "flick": (255, 150, 190),
           "trace": (150, 255, 200), "step": (150, 240, 255)}


def available() -> bool:
    need = ("notes.png", "notes.json", "stage.png", "stage_deco.png", "stage_deco.json",
            os.path.join("combo", "p0.png"), os.path.join("combo", "pt.png"))
    return all(os.path.isfile(os.path.join(ASSETS, n)) for n in need)


def _font(size: int):
    for name in ("segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf", "Arial Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _y_of(p: float) -> float:
    return Y_J / (1.0 + K_DEPTH * p)


def _x_of(lane: float, y: float) -> float:
    return CX + (lane - LANES / 2) / (LANES / 2) * HW * y


def _blit(dst: Image.Image, spr: Image.Image, x: float, y: float) -> None:
    """alpha_composite with clipping."""
    x, y = int(round(x)), int(round(y))
    w, h = spr.size
    l, t = max(0, -x), max(0, -y)
    r, b = min(w, dst.width - x), min(h, dst.height - y)
    if r <= l or b <= t:
        return
    dst.alpha_composite(spr.crop((l, t, r, b)) if (l, t, r, b) != (0, 0, w, h) else spr,
                        (x + l, y + t))


class Renderer:
    def __init__(self, jacket: str | None):
        def atlas(png, js):
            im = Image.open(os.path.join(ASSETS, png)).convert("RGBA")
            data = json.load(open(os.path.join(ASSETS, js), encoding="utf-8"))
            return {s["name"]: im.crop((s["x"], s["y"], s["x"] + s["w"], s["y"] + s["h"]))
                    for s in data["sprites"]}

        self.note = atlas("notes.png", "notes.json")
        self.deco = atlas("stage_deco.png", "stage_deco.json")
        self.digits = {str(i): Image.open(os.path.join(ASSETS, "combo", f"p{i}.png")).convert("RGBA")
                       for i in range(10)}
        self.combo_label = Image.open(os.path.join(ASSETS, "combo", "pt.png")).convert("RGBA")
        self.jacket = self._load_jacket(jacket)
        self.scene = self._build_scene()
        self._cache: dict = {}
        self._fonts: dict[int, ImageFont.ImageFont] = {}

    # ----- static scene -------------------------------------------------------------------
    def _load_jacket(self, path: str | None) -> Image.Image:
        for p in (path, os.path.join(ASSETS, "default_jacket.png")):
            if not p:
                continue
            try:
                with Image.open(p) as im:
                    im = ImageOps.exif_transpose(im).convert("RGBA")
                    side = min(im.size)
                    l, t = (im.width - side) // 2, (im.height - side) // 2
                    return im.crop((l, t, l + side, t + side)).resize((512, 512), Image.Resampling.LANCZOS)
            except Exception:
                continue
        return Image.new("RGBA", (512, 512), (70, 55, 140, 255))

    def _panel(self, name: str, x: float, y: float, w: float, alpha: float = 0.85) -> Image.Image:
        """A jacket-textured side panel cut with the game's own mask sprite."""
        tex, mask = self.deco.get(f"tex_2dmode_jacket_{name}"), self.deco.get(f"tex_2dmode_jacket_{name}_mask")
        layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        if tex is None or mask is None:
            return layer
        tw, th = tex.size
        art = ImageOps.fit(self.jacket, (tw, th), Image.Resampling.LANCZOS)
        art.putalpha(mask.split()[3].point(lambda v: int(v * alpha)))
        grid = tex.copy()
        grid.putalpha(grid.split()[3].point(lambda v: int(v * 0.35)))
        art.alpha_composite(grid)
        k = w / tw
        art = art.resize((max(int(tw * k), 1), max(int(th * k), 1)), Image.Resampling.LANCZOS)
        _blit(layer, art, x, y)
        return layer

    def _build_scene(self) -> Image.Image:
        rnd = random.Random(11)
        base = Image.new("RGBA", (W, H))
        bd = ImageDraw.Draw(base)
        for y in range(H):
            t = y / H
            bd.line([(0, y), (W, y)], fill=(int(_lerp(18, 66, t)), int(_lerp(14, 30, t)),
                                            int(_lerp(60, 132, t)), 255))
        deco = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        dd = ImageDraw.Draw(deco)
        for x in range(10, W, 15):  # equaliser bars
            h = rnd.randint(8, 60)
            dd.rectangle([x, int(H * 0.56) - h, x + 8, int(H * 0.56)], fill=(130, 110, 230, 60))
        for _ in range(28):  # confetti triangles
            cx, cy, r = rnd.randint(0, W), rnd.randint(0, int(H * 0.8)), rnd.randint(6, 22)
            pts = [(cx + rnd.randint(-r, r), cy + rnd.randint(-r, r)) for _ in range(3)]
            dd.polygon(pts, fill=rnd.choice([(90, 200, 255, 70), (170, 130, 255, 70), (255, 130, 200, 55)]))
        base.alpha_composite(deco)

        for name, fx, fy, fw in (("nml_l", 0.17, 0.27, 0.16), ("nml_r", 0.66, 0.07, 0.11),
                                 ("nml_r", 0.79, 0.27, 0.07)):
            base.alpha_composite(self._panel(name, fx * W, fy * H, fw * W))

        # main jacket window (frame inside the 840px sprite: x 152..690, top 141, title bar ~86 high)
        k = 0.476
        win = self.deco["bg_2dmode_window_nml"]
        win = win.resize((int(win.width * k), int(win.height * k)), Image.Resampling.LANCZOS)
        top = int(H * 0.04)
        _blit(base, win, CX - win.width / 2, top - 141 * k)
        side = 215
        art = self.jacket.resize((side, side), Image.Resampling.LANCZOS)
        _blit(base, art, CX - side / 2, top + 19 + 8)

        # mirrored window / jacket on the floor, fading out
        mir = self.deco["bg_2dmode_window_mirror"]
        mir = mir.resize((int(mir.width * k), int(mir.height * k)), Image.Resampling.LANCZOS)
        mtop = int(H * 0.60)
        refl = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        _blit(refl, mir, CX - mir.width / 2, mtop - 180 * k)
        flipped = ImageOps.flip(art)
        _blit(refl, flipped, CX - side / 2, mtop + 8)
        fade = Image.new("L", (W, H), 0)
        fd = ImageDraw.Draw(fade)
        for y in range(mtop, H):
            fd.line([(0, y), (W, y)], fill=int(120 * max(0.0, 1 - (y - mtop) / (H - mtop))))
        refl.putalpha(ImageChops.darker(refl.split()[3], fade))
        base.alpha_composite(refl)

        # floor gradient clipped to the highway
        stage_png = Image.open(os.path.join(ASSETS, "stage.png")).convert("RGBA")
        floor = stage_png.crop((0, 1176, 2048, 1566)).resize((W, 195), Image.Resampling.LANCZOS)
        floor.putalpha(floor.split()[3].point(lambda v: int(v * 0.55)))
        hw_mask = Image.new("L", (W, H), 0)
        ImageDraw.Draw(hw_mask).polygon([(CX, 0), (CX - HW * H, H), (CX + HW * H, H)], fill=255)
        floor_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        floor_layer.alpha_composite(floor, (0, H - 195))
        floor_layer.putalpha(Image.composite(floor_layer.split()[3], Image.new("L", (W, H), 0), hw_mask))
        base.alpha_composite(floor_layer)

        # the highway itself (lane lines + judgement strip)
        stage = stage_png.crop((0, 0, 2048, 1176)).resize((W, H), Image.Resampling.LANCZOS)
        base.alpha_composite(stage)
        return base

    # ----- sprites -----------------------------------------------------------------------
    def _font(self, size: int):
        if size not in self._fonts:
            self._fonts[size] = _font(size)
        return self._fonts[size]

    def _note_sprite(self, name: str, body_w: float, f: float) -> Image.Image:
        key = (name, int(body_w), int(f * 100))
        got = self._cache.get(key)
        if got is not None:
            return got
        spr = self.note[name]
        cap, margin = 90, 57
        ch = max(int(round(spr.height * f)), 1)
        cw = max(int(round(cap * f)), 1)
        total = int(round(body_w + 2 * margin * f))
        mid = max(total - 2 * cw, 2)
        out = Image.new("RGBA", (2 * cw + mid, ch))
        out.paste(spr.crop((0, 0, cap, spr.height)).resize((cw, ch), Image.Resampling.BILINEAR), (0, 0))
        out.paste(spr.crop((cap, 0, spr.width - cap, spr.height)).resize((mid, ch), Image.Resampling.BILINEAR), (cw, 0))
        out.paste(spr.crop((spr.width - cap, 0, spr.width, spr.height)).resize((cw, ch), Image.Resampling.BILINEAR),
                  (cw + mid, 0))
        if len(self._cache) > 600:
            self._cache.clear()
        self._cache[key] = out
        return out

    def _scaled(self, name: str, f: float) -> Image.Image:
        key = ("s", name, int(f * 100))
        got = self._cache.get(key)
        if got is None:
            spr = self.note[name]
            got = spr.resize((max(int(spr.width * f), 1), max(int(spr.height * f), 1)), Image.Resampling.BILINEAR)
            self._cache[key] = got
        return got

    @staticmethod
    def _sprite_name(note) -> str:
        if note.kind == "critical":
            return "notes_0"
        if note.kind == "flick":
            return "notes_3"
        if note.kind == "trace":
            return "notes_4"
        if note.hold:
            return "notes_1"
        return "notes_2"

    # ----- frame -------------------------------------------------------------------------
    def render(self, parsed, times: list[float], clock: float, speed: float, hit_notes) -> Image.Image:
        fall = FALL_BASE / max(speed, 1.0)
        img = self.scene.copy()

        def P(t: float) -> float:
            return (t - clock) / fall

        # hold bodies
        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        od = ImageDraw.Draw(ov)
        for ch in parsed.chains:
            if ch.end < clock or ch.start > clock + fall:
                continue
            crit = any(p.crit for p in ch.points)
            outer = (255, 215, 80, 95) if crit else (80, 230, 170, 95)
            inner = (255, 246, 175, 120) if crit else (195, 255, 232, 120)
            for a, b in zip(ch.points, ch.points[1:]):
                if b.time < clock or a.time > clock + fall:
                    continue
                ta, tb = max(a.time, clock), min(b.time, clock + fall)
                sp = max(b.time - a.time, 1e-9)

                def at(t):
                    k = min(max((t - a.time) / sp, 0.0), 1.0)
                    return a.lane + (b.lane - a.lane) * k, a.width + (b.width - a.width) * k

                (la, wa), (lb, wb) = at(ta), at(tb)
                ya, yb = _y_of(P(ta)), _y_of(P(tb))
                quad = [(_x_of(la, ya), ya), (_x_of(la + wa, ya), ya),
                        (_x_of(lb + wb, yb), yb), (_x_of(lb, yb), yb)]
                od.polygon(quad, fill=outer)
                q = 0.2
                xa0, xa1, xb0, xb1 = quad[0][0], quad[1][0], quad[3][0], quad[2][0]
                od.polygon([(xa0 + (xa1 - xa0) * q, ya), (xa1 - (xa1 - xa0) * q, ya),
                            (xb1 - (xb1 - xb0) * q, yb), (xb0 + (xb1 - xb0) * q, yb)], fill=inner)
        img.alpha_composite(ov)

        # notes, far to near
        lo = bisect.bisect_left(times, clock - 0.004)
        hi = bisect.bisect_right(times, clock + fall)
        for note in reversed(parsed.notes[lo:hi]):
            p = P(note.time)
            y = _y_of(p)
            f = NOTE_F0 * (y / Y_J)
            if f < 0.02 or y > H + 40:
                continue
            x0, x1 = _x_of(note.lane, y), _x_of(note.lane + note.width, y)
            cx = (x0 + x1) / 2
            if note.kind == "step":
                spr = self._scaled("notes_long_among_crtcl" if note.crit else "notes_long_among", f * 0.9)
                _blit(img, spr, cx - spr.width / 2, y - spr.height / 2)
                continue
            body_w = max((x1 - x0) - 6 * f, 2)
            spr = self._note_sprite(self._sprite_name(note), body_w, f)
            _blit(img, spr, cx - spr.width / 2, y - spr.height / 2)
            if note.kind == "flick":
                n = min(max(note.width, 1), 6)
                arrow = self._scaled(f"notes_flick_arrow_0{n}", f)
                _blit(img, arrow, cx - arrow.width / 2, y - spr.height * 0.32 - arrow.height * 0.82)

        # hit effects: light column + diamond
        fx = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        fd = ImageDraw.Draw(fx)
        for note in hit_notes or []:
            age = clock - note.time
            if not 0 <= age <= 0.32:
                continue
            k = age / 0.32
            r, g, b = HIT_RGB.get(note.kind, HIT_RGB["tap"])
            xa, xb = _x_of(note.lane, Y_J), _x_of(note.lane + note.width, Y_J)
            col_h = int(H * 0.32 * (1 - 0.25 * k))
            col = Image.new("RGBA", (max(int(xb - xa), 2), col_h))
            cd = ImageDraw.Draw(col)
            for yy in range(col_h):
                a = int(150 * (1 - k) * (yy / col_h) ** 1.5)
                cd.line([(0, yy), (col.width, yy)], fill=(r, g, b, a))
            _blit(fx, col, xa, Y_J - col_h)
            cxm, rr = (xa + xb) / 2, 14 + 44 * k
            fd.polygon([(cxm, Y_J - rr), (cxm + rr, Y_J), (cxm, Y_J + rr), (cxm - rr, Y_J)],
                       outline=(235, 255, 255, int(255 * (1 - k))), width=max(1, int(4 * (1 - k))))
        img.alpha_composite(fx)
        idx = bisect.bisect_right(times, clock) - 1
        d = ImageDraw.Draw(img)
        if idx >= 0 and clock - times[idx] < 0.5:
            self._text(d, W / 2, Y_J - H * 0.17, "PERFECT", 34, (255, 255, 255, 255), (92, 52, 170, 255))

        # combo (the game's own digit sprites)
        combo = idx + 1
        if combo > 0:
            lbl = self.combo_label
            lbl = lbl.resize((int(lbl.width * 0.85), int(lbl.height * 0.85)), Image.Resampling.LANCZOS)
            _blit(img, lbl, W * 0.865 - lbl.width / 2, H * 0.30)
            digs = [self.digits[c] for c in str(combo)]
            dh = 96
            sized = [dg.resize((int(dg.width * dh / dg.height), dh), Image.Resampling.LANCZOS) for dg in digs]
            total = sum(int(s.width * 0.86) for s in sized)
            x = W * 0.865 - total / 2
            for s in sized:
                _blit(img, s, x, H * 0.37)
                x += int(s.width * 0.86)

        self._hud(img, parsed, combo, clock)
        return img

    def _text(self, d, x, y, text, size, fill, shadow, anchor="mm") -> None:
        f = self._font(size)
        for dx, dy in ((-2, -2), (2, -2), (-2, 2), (2, 2), (0, 3)):
            d.text((x + dx, y + dy), text, font=f, fill=shadow, anchor=anchor)
        d.text((x, y), text, font=f, fill=fill, anchor=anchor)

    def _hud(self, img: Image.Image, parsed, combo: int, clock: float) -> None:
        total = max(len(parsed.notes), 1)
        frac = min(combo / total, 1.0)
        hud = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        hd = ImageDraw.Draw(hud)
        hd.polygon([(0, 0), (W * 0.42, 0), (W * 0.40, H * 0.16), (0, H * 0.16)], fill=(14, 8, 44, 150))
        hd.polygon([(W * 0.60, 0), (W, 0), (W, H * 0.12), (W * 0.62, H * 0.12)], fill=(14, 8, 44, 150))
        img.alpha_composite(hud)
        d = ImageDraw.Draw(img)
        d.polygon([(30, 6), (56, 30), (30, 54), (4, 30)], fill=(36, 26, 88, 255), outline=(207, 194, 255, 255))
        rank = "S" if frac >= 0.89 else "A" if frac >= 0.74 else "B" if frac >= 0.59 else "C" if frac >= 0.45 else "-"
        self._text(d, 30, 31, rank, 20, (255, 255, 255, 255), (36, 26, 88, 255))
        bx0, bx1, by0, by1 = 70, int(W * 0.37), 24, 36
        d.text((bx0, 12), "SCORE", font=self._font(12), fill=(255, 255, 255, 255), anchor="lm")
        d.rectangle([bx0, by0, bx1, by1], fill=(42, 36, 88, 255), outline=(207, 194, 255, 255))
        d.rectangle([bx0, by0, bx0 + (bx1 - bx0) * frac, by1], fill=(155, 229, 100, 255))
        for letter, pos in (("C", 0.45), ("B", 0.59), ("A", 0.74), ("S", 0.89)):
            x = bx0 + (bx1 - bx0) * pos
            d.text((x, 12), letter, font=self._font(11), fill=(255, 255, 255, 255), anchor="mm")
            d.line([(x, by0), (x, by1)], fill=(207, 194, 255, 255))
        self._text(d, bx0, 64, f"{int(1_000_000 * frac):08d}", 28, (255, 255, 255, 255), (43, 31, 110, 255), "lm")
        d.text((W * 0.66, 22), "LIFE", font=self._font(13), fill=(255, 255, 255, 255), anchor="lm")
        d.text((W - 80, 22), "1000", font=self._font(17), fill=(255, 255, 255, 255), anchor="rm")
        d.text((W * 0.635, 42), "\u2665", font=self._font(18), fill=(155, 229, 100, 255), anchor="mm")
        d.rectangle([W * 0.655, 38, W - 80, 47], fill=(155, 229, 100, 255), outline=(216, 255, 192, 255))
        px0, py0, px1, py1 = PAUSE_BOX
        d.rounded_rectangle([px0, py0, px1, py1], 8, fill=(255, 255, 255, 255), outline=(207, 194, 255, 255), width=2)
        d.rectangle([px0 + 14, py0 + 12, px0 + 21, py1 - 12], fill=(42, 36, 88, 255))
        d.rectangle([px1 - 21, py0 + 12, px1 - 14, py1 - 12], fill=(42, 36, 88, 255))
        d.text((12, H - 8), f"{max(clock, 0):.1f}s / {parsed.duration:.1f}s   {len(parsed.notes)} notes",
               font=self._font(12), fill=(188, 178, 230, 255), anchor="ls")
