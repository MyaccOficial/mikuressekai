"""Chart preview: notes falling on a 12-lane field, with the song when ffplay is available.

Reads .sus and .usc charts directly (taps, flicks, traces, holds/slides, critical notes, BPM and
time-signature changes), so it needs nothing but tkinter (Pillow only for the jacket background).
The bundles in bases/ are plain Unity compile templates with no note skins, so the preview draws
everything itself from the chart, the audio and the jacket, in the look of the game.
"""
from __future__ import annotations

import bisect
import re
import subprocess
import time
import tkinter as tk
from dataclasses import dataclass, field
from tkinter import ttk

import deps

LANES = 12
W, H = 960, 540
JUDGE_Y = int(H * 0.80)
LEAD_SECONDS = 2.0


@dataclass
class Note:
    time: float
    lane: int
    width: int
    kind: str  # tap | critical | flick | trace | step
    hold: bool = False  # head/tail of a hold
    crit: bool = False  # belongs to a critical hold


@dataclass
class Chain:
    points: list[Note] = field(default_factory=list)

    @property
    def start(self) -> float:
        return self.points[0].time

    @property
    def end(self) -> float:
        return self.points[-1].time


@dataclass
class Parsed:
    notes: list[Note]
    chains: list[Chain]
    duration: float


_HEADER = re.compile(r"^#(\d{3})([0-9A-Za-z]{2,3}):\s*([0-9A-Za-z]*)\s*$")
_BPM_DEF = re.compile(r"^#BPM([0-9A-Za-z]{2}):\s*([\d.]+)\s*$", re.IGNORECASE)
_TPB = re.compile(r'^#REQUEST\s+"ticks_per_beat\s+(\d+)"', re.IGNORECASE)


def parse_sus(text: str) -> Parsed:
    tpb = 480
    bpm_defs: dict[str, float] = {}
    measure_beats: dict[int, float] = {}
    rows: list[tuple[int, str, str]] = []
    for raw in text.splitlines():
        line = raw.strip()
        m = _TPB.match(line)
        if m:
            tpb = int(m.group(1))
            continue
        m = _BPM_DEF.match(line)
        if m:
            bpm_defs[m.group(1).upper()] = float(m.group(2))
            continue
        m = _HEADER.match(line)
        if not m:
            continue
        measure, ch, data = int(m.group(1)), m.group(2), m.group(3)
        if ch == "02":
            try:
                measure_beats[measure] = float(data)
            except ValueError:
                pass
            continue
        rows.append((measure, ch, data))
    if not rows:
        raise ValueError("the chart has no notes")

    last = max(r[0] for r in rows)
    start_tick = [0.0]
    for i in range(last + 1):
        start_tick.append(start_tick[-1] + measure_beats.get(i, 4.0) * tpb)

    def tick_of(measure: int, i: int, n: int) -> float:
        length = start_tick[measure + 1] - start_tick[measure]
        return start_tick[measure] + length * i / n

    bpm_events: list[tuple[float, float]] = []
    for measure, ch, data in rows:
        if ch == "08":
            n = len(data) // 2
            for i in range(n):
                key = data[2 * i : 2 * i + 2].upper()
                if key != "00" and key in bpm_defs:
                    bpm_events.append((tick_of(measure, i, n), bpm_defs[key]))
    bpm_events.sort()
    default_bpm = bpm_defs.get("00") or (next(iter(bpm_defs.values())) if bpm_defs else 120.0)
    if not bpm_events or bpm_events[0][0] > 0:
        bpm_events.insert(0, (0.0, default_bpm))

    seg_start = [0.0]
    for (t0, b0), (t1, _b1) in zip(bpm_events, bpm_events[1:]):
        seg_start.append(seg_start[-1] + (t1 - t0) / tpb * 60.0 / b0)
    ticks = [e[0] for e in bpm_events]

    def seconds(tick: float) -> float:
        k = max(bisect.bisect_right(ticks, tick) - 1, 0)
        return seg_start[k] + (tick - ticks[k]) / tpb * 60.0 / bpm_events[k][1]

    notes: list[Note] = []
    slide_points: dict[str, list[tuple[float, str, Note]]] = {}
    for measure, ch, data in rows:
        n = len(data) // 2
        if n == 0:
            continue
        if ch[0] == "1" and len(ch) == 2:
            lane = int(ch[1], 16) - 2
            for i in range(n):
                pair = data[2 * i : 2 * i + 2]
                if pair == "00":
                    continue
                kind = {"1": "tap", "2": "critical", "3": "flick"}.get(pair[0], "tap")
                notes.append(
                    Note(seconds(tick_of(measure, i, n)), lane, int(pair[1], 16), kind)
                )
        elif ch[0] == "3" and len(ch) == 3:
            lane = int(ch[1], 16) - 2
            for i in range(n):
                pair = data[2 * i : 2 * i + 2]
                if pair == "00":
                    continue
                tick = tick_of(measure, i, n)
                note = Note(seconds(tick), lane, int(pair[1], 16), "step")
                slide_points.setdefault(ch[2], []).append((tick, pair[0], note))

    chains: list[Chain] = []
    for pts in slide_points.values():
        pts.sort(key=lambda p: p[0])
        chain: Chain | None = None
        for _tick, typ, note in pts:
            if typ == "1" or chain is None:
                chain = Chain()
                chains.append(chain)
            chain.points.append(note)
            if typ == "1" or typ == "2":
                note.kind = "tap"
                note.hold = True
            elif typ == "5":
                note.kind = "hidden"
            if typ == "2":
                chain = None
    chains = [c for c in chains if len(c.points) >= 2]
    for c in chains:
        notes.extend(p for p in c.points if p.kind != "hidden")

    notes.sort(key=lambda n: n.time)
    duration = max([n.time for n in notes] + [c.end for c in chains] + [0.0])
    return Parsed(notes, chains, duration)


def parse_usc(text: str) -> Parsed:
    import json

    data = json.loads(text.lstrip("\ufeff"))
    usc = data.get("usc", data)
    objects = usc.get("objects", [])
    bpms = sorted(
        (float(o["beat"]), float(o["bpm"])) for o in objects if o.get("type") == "bpm"
    ) or [(0.0, 120.0)]
    if bpms[0][0] > 0:
        bpms.insert(0, (0.0, bpms[0][1]))
    seg = [0.0]
    for (b0, v0), (b1, _v1) in zip(bpms, bpms[1:]):
        seg.append(seg[-1] + (b1 - b0) * 60.0 / v0)
    beats = [b for b, _ in bpms]

    def seconds(beat: float) -> float:
        k = max(bisect.bisect_right(beats, beat) - 1, 0)
        return seg[k] + (beat - beats[k]) * 60.0 / bpms[k][1]

    def mk(beat, lane, size, kind) -> Note:
        return Note(seconds(float(beat)), int(round(float(lane) - float(size) + 6)),
                    max(int(round(float(size) * 2)), 1), kind)

    notes: list[Note] = []
    chains: list[Chain] = []
    for o in objects:
        typ = o.get("type")
        if typ == "single":
            if o.get("critical"):
                kind = "critical"
            elif o.get("flick", "none") not in ("none", None):
                kind = "flick"
            elif o.get("trace"):
                kind = "trace"
            else:
                kind = "tap"
            notes.append(mk(o["beat"], o["lane"], o["size"], kind))
        elif typ == "slide":
            crit = bool(o.get("critical"))
            chain = Chain()
            for c in o.get("connections", []):
                ct = c.get("type")
                if ct == "attach":
                    kind = "hidden"
                elif ct == "tick":
                    kind = "step"
                elif c.get("flick", "none") not in ("none", None):
                    kind = "flick"
                else:
                    kind = "critical" if crit else "tap"
                pt = mk(c["beat"], c["lane"], c["size"], kind)
                pt.hold = ct in ("start", "end")
                pt.crit = crit
                chain.points.append(pt)
            if len(chain.points) >= 2:
                chains.append(chain)
                notes.extend(p for p in chain.points if p.kind != "hidden")
    if not notes:
        raise ValueError("the chart has no notes")
    notes.sort(key=lambda n: n.time)
    duration = max([n.time for n in notes] + [c.end for c in chains])
    return Parsed(notes, chains, duration)


def parse_file(path: str) -> Parsed:
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        text = f.read()
    if path.lower().endswith(".usc"):
        return parse_usc(text)
    return parse_sus(text)


COLORS = {  # (fill, outline)
    "tap": ("#f4f0ff", "#9b7bff"),
    "critical": ("#fff3b0", "#f2c200"),
    "flick": ("#ffe3e8", "#ff5c7c"),
    "trace": ("#d9ffe9", "#4fd89a"),
    "step": ("#e8fbff", "#6fd2ff"),
}
HOLD_COLORS = {"critical": ("#a8870f", "#ffe27a"), "default": ("#2f9486", "#9ff3df")}

CX = W / 2
VP_Y = -0.03 * H          # vanishing point, just above the top edge (as in the game)
HALF_W0 = 0.338 * W       # half width of the highway at the judgement line
K_DEPTH = 22.0            # perspective strength: scale at the far end = 1 / (1 + K)
FALL_BASE = 620.0         # fall time in seconds = FALL_BASE / speed slider value
PAUSE_BOX = (W - 58, 12, W - 12, 58)
RANK_MARKS = (("C", 0.45), ("B", 0.59), ("A", 0.74), ("S", 0.89))


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _proj(lane: float, p: float) -> tuple[float, float, float]:
    """Lane position (0..12) at depth p (0 = judgement line, 1 = far end) -> x, y, scale."""
    s = 1.0 / (1.0 + K_DEPTH * p)
    return (CX + (lane - LANES / 2) / (LANES / 2) * HALF_W0 * s,
            VP_Y + (JUDGE_Y - VP_Y) * s, s)


def _edge_x(lane: float, y: float) -> float:
    s = (y - VP_Y) / (JUDGE_Y - VP_Y)
    return CX + (lane - LANES / 2) / (LANES / 2) * HALF_W0 * s


def _at(a: Note, b: Note, t: float) -> tuple[float, float]:
    span = b.time - a.time
    k = 0.0 if span <= 0 else min(max((t - a.time) / span, 0.0), 1.0)
    return a.lane + (b.lane - a.lane) * k, a.width + (b.width - a.width) * k


def build_scene(jacket: str | None):
    """Static layer (stage, jacket panel + reflection, glass highway, neon judgement strip),
    composed with Pillow. Returns a PhotoImage, or None when Pillow is not available."""
    try:
        import random

        from PIL import Image, ImageDraw, ImageFilter, ImageOps, ImageTk
    except Exception:
        return None
    rnd = random.Random(7)

    jac = None
    if jacket:
        try:
            with Image.open(jacket) as im:
                im = ImageOps.exif_transpose(im).convert("RGBA")
                side = min(im.size)
                l, t = (im.width - side) // 2, (im.height - side) // 2
                jac = im.crop((l, t, l + side, t + side)).resize((512, 512), Image.Resampling.LANCZOS)
        except Exception:
            jac = None

    base = Image.new("RGBA", (W, H))
    bd = ImageDraw.Draw(base)
    for y in range(H):
        t = y / H
        bd.line([(0, y), (W, y)], fill=(int(_lerp(22, 92, t)), int(_lerp(16, 38, t)),
                                        int(_lerp(78, 172, t)), 255))

    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    for x in range(8, W, 14):  # equaliser bars
        h = rnd.randint(10, 70)
        ld.rectangle([x, int(H * 0.56) - h, x + 8, int(H * 0.56)], fill=(130, 110, 230, 70))
    for _ in range(30):  # confetti triangles
        cx_, cy_, r = rnd.randint(0, W), rnd.randint(0, int(H * 0.8)), rnd.randint(8, 26)
        pts = [(cx_ + rnd.randint(-r, r), cy_ + rnd.randint(-r, r)) for _ in range(3)]
        ld.polygon(pts, fill=rnd.choice([(90, 200, 255, 80), (170, 130, 255, 80), (255, 130, 200, 60)]))
    for x0, y0, x1, y1 in ((0.17, 0.27, 0.31, 0.50), (0.62, 0.20, 0.80, 0.46),
                           (0.05, 0.12, 0.16, 0.30), (0.84, 0.42, 0.95, 0.60)):
        box = [int(x0 * W), int(y0 * H), int(x1 * W), int(y1 * H)]
        ld.rectangle(box, fill=(150, 135, 255, 55), outline=(205, 195, 255, 140), width=2)
        if jac is not None:
            tile = jac.resize((box[2] - box[0] - 8, box[3] - box[1] - 8))
            tile.putalpha(80)
            layer.paste(tile, (box[0] + 4, box[1] + 4), tile)
    base = Image.alpha_composite(base, layer)

    J = int(H * 0.50)
    jx, jy = int(CX) - J // 2, int(H * 0.035)
    art = jac.resize((J, J), Image.Resampling.LANCZOS) if jac is not None else Image.new(
        "RGBA", (J, J), (70, 55, 140, 255))
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(glow).rectangle([jx - 10, jy - 10, jx + J + 10, jy + J + 10], fill=(170, 140, 255, 120))
    base = Image.alpha_composite(base, glow.filter(ImageFilter.GaussianBlur(12)))
    frame = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(frame).rectangle([jx - 5, jy - 5, jx + J + 5, jy + J + 5], fill=(18, 14, 46, 240),
                                    outline=(190, 175, 255, 220), width=2)
    frame.paste(art, (jx, jy))
    base = Image.alpha_composite(base, frame)

    rw, rh = int(J * 0.9), int(J * 0.5)  # reflection on the floor
    refl = art.transpose(Image.FLIP_TOP_BOTTOM).resize((rw, int(J * 0.9))).crop((0, 0, rw, rh))
    mask = Image.new("L", (rw, rh))
    md = ImageDraw.Draw(mask)
    for yy in range(rh):
        md.line([(0, yy), (rw, yy)], fill=int(90 * (1 - yy / rh)))
    refl.putalpha(mask)
    base.alpha_composite(refl, (int(CX) - rw // 2, int(H * 0.60)))

    hw = Image.new("RGBA", (W, H), (0, 0, 0, 0))  # glass highway, more opaque towards the player
    hd = ImageDraw.Draw(hw)
    slices = 48
    for i in range(slices):
        y0, y1 = H * i / slices, H * (i + 1) / slices + 1
        a = int(_lerp(35, 125, (y0 / H) ** 1.2))
        hd.polygon([(_edge_x(0, y0), y0), (_edge_x(LANES, y0), y0),
                    (_edge_x(LANES, y1), y1), (_edge_x(0, y1), y1)], fill=(190, 170, 255, a))
    for i in range(LANES + 1):
        edge = i in (0, LANES)
        hd.line([(_edge_x(i, 0), 0), (_edge_x(i, H), H)],
                fill=(238, 228, 255, 235 if edge else 120), width=3 if edge else 1)
    base = Image.alpha_composite(base, hw)

    yt, yb = JUDGE_Y - int(H * 0.032), JUDGE_Y + int(H * 0.034)
    quad = [(_edge_x(0, yt), yt), (_edge_x(LANES, yt), yt), (_edge_x(LANES, yb), yb), (_edge_x(0, yb), yb)]
    strip = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(strip)
    sd.polygon(quad, fill=(28, 10, 58, 215))
    for i in range(0, LANES, 2):
        sd.polygon([(_edge_x(i, yt), yt), (_edge_x(i + 1, yt), yt),
                    (_edge_x(i + 1, yb), yb), (_edge_x(i, yb), yb)], fill=(120, 70, 210, 90))
    for i in range(1, LANES):
        sd.line([(_edge_x(i, yt), yt), (_edge_x(i, yb), yb)], fill=(200, 170, 255, 170), width=1)
    neon = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(neon).line(quad + [quad[0]], fill=(255, 120, 230, 255), width=7)
    base = Image.alpha_composite(base, neon.filter(ImageFilter.GaussianBlur(5)))
    sd.line(quad + [quad[0]], fill=(255, 160, 238, 255), width=3)
    base = Image.alpha_composite(base, strip)
    return ImageTk.PhotoImage(base.convert("RGB"))


def _fallback_scene(c) -> None:
    c.create_rectangle(0, 0, W, H, fill="#1c1450", outline="")
    c.create_polygon(_edge_x(0, 0), 0, _edge_x(LANES, 0), 0, _edge_x(LANES, H), H, _edge_x(0, H), H,
                     fill="#b9a8ff", outline="", stipple="gray25")
    for i in range(LANES + 1):
        c.create_line(_edge_x(i, 0), 0, _edge_x(i, H), H, fill="#e6dcff")
    yt, yb = JUDGE_Y - 17, JUDGE_Y + 18
    c.create_polygon(_edge_x(0, yt), yt, _edge_x(LANES, yt), yt, _edge_x(LANES, yb), yb,
                     _edge_x(0, yb), yb, fill="#1c0a3a", outline="#ff9ff0", width=3)


def _shadow_text(c, x, y, text, font, fill, shadow="#5b2fa0", anchor="center") -> None:
    for dx, dy in ((-2, -2), (2, -2), (-2, 2), (2, 2), (0, 3)):
        c.create_text(x + dx, y + dy, text=text, font=font, fill=shadow, anchor=anchor)
    c.create_text(x, y, text=text, font=font, fill=fill, anchor=anchor)


def draw_frame(c, parsed: Parsed, times: list[float], clock: float, speed: float,
               scene=None, hit_notes=None) -> None:
    """Draw one frame of the game-style view on a tk-canvas-like object `c`."""
    fall = FALL_BASE / max(speed, 1.0)
    c.delete("all")
    if scene is not None:
        c.create_image(0, 0, image=scene, anchor="nw")
    else:
        _fallback_scene(c)

    def P(t: float) -> float:
        return (t - clock) / fall

    # hold bodies, clipped to the visible depth range
    for ch in parsed.chains:
        if ch.end < clock or ch.start > clock + fall:
            continue
        outer, inner = HOLD_COLORS["critical" if any(p.kind == "critical" for p in ch.points) else "default"]
        for a, b in zip(ch.points, ch.points[1:]):
            if b.time < clock or a.time > clock + fall:
                continue
            ta, tb = max(a.time, clock), min(b.time, clock + fall)
            (la, wa), (lb, wb) = _at(a, b, ta), _at(a, b, tb)
            ax0, ay, _ = _proj(la, P(ta))
            ax1, _, _ = _proj(la + wa, P(ta))
            bx0, by, _ = _proj(lb, P(tb))
            bx1, _, _ = _proj(lb + wb, P(tb))
            c.create_polygon(ax0, ay, ax1, ay, bx1, by, bx0, by, fill=outer, outline="", stipple="gray50")
            q = 0.2
            c.create_polygon(ax0 + (ax1 - ax0) * q, ay, ax1 - (ax1 - ax0) * q, ay,
                             bx1 - (bx1 - bx0) * q, by, bx0 + (bx1 - bx0) * q, by,
                             fill=inner, outline="", stipple="gray50")

    # notes, far to near
    lo = bisect.bisect_left(times, clock - 0.01)
    hi = bisect.bisect_right(times, clock + fall)
    for note in reversed(parsed.notes[lo:hi]):
        x0, y, s = _proj(note.lane, P(note.time))
        x1, _, _ = _proj(note.lane + note.width, P(note.time))
        x0, x1 = x0 + 2, x1 - 2
        if x1 - x0 < 3:  # far-away notes: keep a drawable minimum width
            x0, x1 = (x0 + x1) / 2 - 2, (x0 + x1) / 2 + 2
        fill, line = COLORS.get(note.kind, COLORS["tap"])
        if note.kind == "step":
            cx, r = (x0 + x1) / 2, 15 * s + 2
            c.create_polygon(cx, y - r, cx + r, y, cx, y + r, cx - r, y, fill=fill, outline=line, width=2)
            continue
        th = (0.016 if note.kind == "trace" else 0.026) * H * s
        c.create_rectangle(x0, y - th, x1, y + th, fill=fill, outline=line, width=max(2, int(3 * s)))
        c.create_rectangle(x0 + (x1 - x0) * 0.08, y - th * 0.45, x1 - (x1 - x0) * 0.08, y + th * 0.2,
                           fill="#ffffff", outline="")
        c.create_rectangle(x0 - 1, y - th * 0.3, x0 + 5 * s, y + th * 0.3, fill=line, outline="")
        c.create_rectangle(x1 - 5 * s, y - th * 0.3, x1 + 1, y + th * 0.3, fill=line, outline="")
        if note.kind == "flick":
            w = min((x1 - x0) * 0.55, 110 * s)
            cx, yb = (x0 + x1) / 2, y - th - 5 * s
            h, t = w * 0.5, w * 0.22
            c.create_polygon(cx - w / 2, yb, cx, yb - h, cx + w / 2, yb, cx + w / 2, yb + t,
                             cx, yb - h + t, cx - w / 2, yb + t, fill="#ff8da3", outline="#ffd9e0", width=2)

    # hit effects: light column, diamond burst, judgement text
    recent = hit_notes or []
    for note in recent:
        age = clock - note.time
        if not 0 <= age <= 0.3:
            continue
        k = age / 0.3
        xa, ya, _ = _proj(note.lane, 0)
        xb, _, _ = _proj(note.lane + note.width, 0)
        col_h = H * 0.26 * (1 - 0.3 * k)
        st = "gray50" if k < 0.45 else "gray25"
        c.create_rectangle(xa, ya - col_h, xb, ya, fill="#7ff5e6", outline="", stipple=st)
        c.create_rectangle(xa + (xb - xa) * 0.15, ya - col_h * 0.7, xb - (xb - xa) * 0.15, ya,
                           fill="#ffffff", outline="", stipple="gray25")
        cx, r = (xa + xb) / 2, 18 + 46 * k
        c.create_polygon(cx, ya - r, cx + r, ya, cx, ya + r, cx - r, ya, fill="", outline="#e8fffb",
                         width=max(1, int(4 * (1 - k))))
    idx = bisect.bisect_right(times, clock) - 1
    if idx >= 0 and clock - times[idx] < 0.5:
        _shadow_text(c, CX, JUDGE_Y - H * 0.16, "PERFECT", ("Segoe UI", 26, "bold italic"), "#ffffff")

    # HUD
    total = max(len(parsed.notes), 1)
    combo = bisect.bisect_right(times, clock)
    frac = combo / total
    score = int(1_000_000 * frac)
    c.create_polygon(0, 0, W * 0.40, 0, W * 0.38, H * 0.17, 0, H * 0.17, fill="#10082c", outline="", stipple="gray50")
    c.create_polygon(8, 8, 52, 8, 52, 52, 8, 52, fill="#241a58", outline="#cfc2ff", width=2)
    c.create_text(30, 30, text="C" if frac < 0.45 else "B" if frac < 0.59 else "A" if frac < 0.74 else "S",
                  fill="#ffffff", font=("Segoe UI", 18, "bold"))
    bx0, bx1, by0, by1 = 64, int(W * 0.36), 22, 34
    c.create_text(bx0, 12, text="SCORE", anchor="w", fill="#ffffff", font=("Segoe UI", 10, "bold"))
    c.create_rectangle(bx0, by0, bx1, by1, fill="#2a2458", outline="#cfc2ff")
    c.create_rectangle(bx0, by0, bx0 + (bx1 - bx0) * frac, by1, fill="#9be564", outline="")
    for letter, pos in RANK_MARKS:
        x = bx0 + (bx1 - bx0) * pos
        c.create_text(x, 10, text=letter, fill="#ffffff", font=("Segoe UI", 9, "bold"))
        c.create_line(x, by0, x, by1, fill="#cfc2ff")
    _shadow_text(c, bx0, 62, f"{score:08d}", ("Segoe UI", 24, "bold"), "#ffffff", "#2b1f6e", "w")

    c.create_polygon(W * 0.60, 0, W, 0, W, H * 0.13, W * 0.62, H * 0.13, fill="#10082c", outline="", stipple="gray50")
    c.create_text(W * 0.66, 22, text="LIFE", anchor="w", fill="#ffffff", font=("Segoe UI", 11, "bold"))
    c.create_text(W - 76, 22, text="1000", anchor="e", fill="#ffffff", font=("Segoe UI", 14, "bold"))
    c.create_text(W * 0.635, 40, text="\u2665", fill="#9be564", font=("Segoe UI", 16, "bold"))
    c.create_rectangle(W * 0.655, 38, W - 76, 46, fill="#9be564", outline="#d8ffc0")
    px0, py0, px1, py1 = PAUSE_BOX
    c.create_rectangle(px0, py0, px1, py1, fill="#ffffff", outline="#cfc2ff", width=2)
    c.create_rectangle(px0 + 13, py0 + 11, px0 + 20, py1 - 11, fill="#2a2458", outline="")
    c.create_rectangle(px1 - 20, py0 + 11, px1 - 13, py1 - 11, fill="#2a2458", outline="")
    if combo > 0:
        _shadow_text(c, W * 0.88, H * 0.36, "COMBO", ("Segoe UI", 15, "bold"), "#f1e8ff")
        _shadow_text(c, W * 0.88, H * 0.47, str(combo), ("Segoe UI", 54, "bold"), "#ffffff")
    c.create_text(12, H - 10, anchor="sw", fill="#bcb2e6", font=("Segoe UI", 10),
                  text=f"{max(clock, 0):.1f}s / {parsed.duration:.1f}s   {len(parsed.notes)} notes")


class PreviewWindow(tk.Toplevel):
    def __init__(self, parent, parsed: Parsed, title: str, audio: str | None,
                 offset_ms: int, jacket: str | None):
        super().__init__(parent)
        self.title(f"Preview - {title}")
        self.resizable(False, False)
        self.parsed = parsed
        self.audio = audio
        self.offset = offset_ms / 1000.0
        self.times = [n.time for n in parsed.notes]
        self.renderer = None
        try:  # sprite-based look (MikuMikuWorld assets in preview_assets/), if available
            import mmw_render

            if mmw_render.available():
                self.renderer = mmw_render.Renderer(jacket)
        except Exception:
            self.renderer = None
        if self.renderer is not None:
            self.screen = tk.Label(self, bd=0, highlightthickness=0, bg="#0b0b14")
            self.screen.pack()
            self.screen.bind("<Button-1>", self._click)
            self.canvas = None
            self.scene = None
        else:  # fallback: drawn with the canvas only
            self.canvas = tk.Canvas(self, width=W, height=H, bg="#0b0b14", highlightthickness=0)
            self.canvas.pack()
            self.canvas.bind("<Button-1>", self._click)
            try:
                self.scene = build_scene(jacket)
            except Exception:
                self.scene = None

        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=6, pady=6)
        self.pause_btn = ttk.Button(bar, text="Pause", command=self.toggle)
        self.pause_btn.pack(side="left")
        ttk.Button(bar, text="Restart", command=self.restart).pack(side="left", padx=6)
        ttk.Label(bar, text="Speed").pack(side="left", padx=(12, 4))
        self.speed = tk.DoubleVar(value=520)
        ttk.Scale(bar, from_=250, to=1200, variable=self.speed, length=180).pack(side="left")

        self.proc: subprocess.Popen | None = None
        self.audio_started = False
        self.paused = False
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.restart()
        self._tick()

    def _click(self, event):
        if self.renderer is not None:
            import mmw_render

            x0, y0, x1, y1 = mmw_render.PAUSE_BOX
        else:
            x0, y0, x1, y1 = PAUSE_BOX
        if x0 <= event.x <= x1 and y0 <= event.y <= y1:
            self.toggle()

    def _stop_audio(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
        self.proc = None
        self.audio_started = False

    def restart(self):
        self._stop_audio()
        self.clock = -LEAD_SECONDS
        self.last = time.perf_counter()
        self.paused = False
        self.pause_btn.config(text="Pause")

    def toggle(self):
        self.paused = not self.paused
        self.pause_btn.config(text="Resume" if self.paused else "Pause")
        if self.paused:
            self._stop_audio()
        else:
            self.last = time.perf_counter()

    def close(self):
        self._stop_audio()
        self.destroy()

    def _start_audio(self):
        ffplay = deps.find_tool("ffplay")
        if not self.audio or not ffplay:
            return
        seek = max(self.clock - self.offset, 0.0)
        cmd = [ffplay, "-nodisp", "-autoexit", "-loglevel", "quiet", "-ss", f"{seek:.3f}", self.audio]
        flags = 0x08000000 if hasattr(subprocess, "STARTUPINFO") else 0
        try:
            self.proc = subprocess.Popen(cmd, creationflags=flags)
        except OSError:
            self.proc = None

    def _tick(self):
        if not self.winfo_exists():
            return
        now = time.perf_counter()
        if not self.paused:
            self.clock += now - self.last
            if not self.audio_started and self.clock >= self.offset:
                self.audio_started = True
                self._start_audio()
        self.last = now
        lo = bisect.bisect_left(self.times, self.clock - 0.35)
        hi = bisect.bisect_right(self.times, self.clock)
        if self.renderer is not None:
            from PIL import ImageTk

            frame = self.renderer.render(self.parsed, self.times, self.clock, self.speed.get(),
                                         self.parsed.notes[lo:hi])
            self.photo = ImageTk.PhotoImage(frame.convert("RGB"))
            self.screen.configure(image=self.photo)
            self.after(24, self._tick)
            return
        draw_frame(self.canvas, self.parsed, self.times, self.clock, self.speed.get(),
                   self.scene, self.parsed.notes[lo:hi])
        self.after(16, self._tick)
