from __future__ import annotations

import importlib
import importlib.metadata
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# builder/vendor is only a last-resort fallback, searched AFTER the installed packages so a
# partial copy there can never shadow a working install.
VENDOR = os.path.join(HERE, "vendor")
if os.path.isdir(VENDOR) and VENDOR not in sys.path:
    sys.path.append(VENDOR)
BASES = os.path.join(HERE, "bases")

# (pip name, import name, minimum version); keep in sync with requirements.txt
PACKAGES: list[tuple[str, str, tuple[int, ...] | None]] = [
    ("Pillow", "PIL", None),
    ("rg-converters", "rg_converters", (2, 2, 2)),
    ("UnityPy", "UnityPy", None),
    ("cricodecs", "cricodecs", (1, 2, 0)),
]


def find_tool(name: str) -> str | None:
    """`name` on PATH, else next to the builder; it is not looked for anywhere else."""
    on_path = shutil.which(name)
    if on_path:
        return on_path
    local = os.path.join(HERE, name + (".exe" if os.name == "nt" else ""))
    return local if os.path.isfile(local) else None


FFMPEG = find_tool("ffmpeg")
FFPROBE = find_tool("ffprobe")


def _version(text: str) -> tuple[int, ...]:
    return tuple(int(part) for part in re.findall(r"\d+", text)[:3])


def _dotted(version: tuple[int, ...]) -> str:
    return ".".join(map(str, version))


RG_SUBMODULES = (
    "rg_converters.core.score",
    "rg_converters.converters",
    "rg_converters.converters.LevelData",
)


def _rg_converters_problems(pip_name: str) -> list[str]:
    """rg_converters imports but lacks the parts the builder uses: say which copy is loaded."""
    import rg_converters

    out: list[str] = []
    try:
        installed = importlib.metadata.version(pip_name)
    except Exception:
        installed = ""
    if installed and _version(installed) >= (3,):
        return [
            f"rg-converters {installed} is too new: version 3 reorganised the package and has no "
            "rg_converters.converters, which this builder uses. Install the 2.x line with:\n"
            f'    "{sys.executable}" -m pip install -U "rg-converters>=2.2.2,<3"'
        ]
    for sub in RG_SUBMODULES:
        try:
            importlib.import_module(sub)
        except Exception as e:
            try:
                version = importlib.metadata.version(pip_name)
            except Exception:
                version = "unknown"
            where = getattr(rg_converters, "__file__", None) or str(
                list(getattr(rg_converters, "__path__", []))
            )
            out.append(
                f"{sub} failed to load ({type(e).__name__}: {e}). The rg_converters in use is "
                f"version {version} at {where}. It is an old, partial or wrong copy: run "
                "install_deps.bat (it removes it and reinstalls) and delete the builder/vendor folder."
            )
            break
    return out


def problems() -> list[str]:
    out: list[str] = []
    for tool, path in (("ffmpeg", FFMPEG), ("ffprobe", FFPROBE)):
        if not path:
            out.append(f"{tool} was not found on PATH or next to main.py.")
    for pip_name, module, minimum in PACKAGES:
        try:
            importlib.import_module(module)
        except Exception as e:
            out.append(
                f"{pip_name} is not installed or failed to load "
                f"({type(e).__name__}: {e}). Python in use: {sys.executable}"
            )
            continue
        if module == "rg_converters":
            out.extend(_rg_converters_problems(pip_name))
        if minimum is None:
            continue
        try:
            installed = importlib.metadata.version(pip_name)
        except importlib.metadata.PackageNotFoundError:
            out.append(f"{pip_name} {_dotted(minimum)} or newer is required (installed version unknown).")
            continue
        if _version(installed) < minimum:
            out.append(f"{pip_name} {_dotted(minimum)} or newer is required, {installed} is installed.")

    import encode

    missing = encode.missing_bases(BASES)
    if missing:
        out.append("Base bundles missing from the bases folder: " + ", ".join(missing))
    return out


FIXES = (
    "Install the Python packages with the SAME Python that runs main.py:\n"
    f"    \"{sys.executable}\" -m pip install -U -r requirements.txt\n"
    "(a plain 'pip' often installs into a different Python, which causes errors such as\n"
    " \"No module named rg_converters\"). Git must be on PATH if pip has to fetch a package from GitHub.\n"
    "Install FFmpeg (ffmpeg.org) and put it on PATH, or copy ffmpeg and ffprobe next to main.py.\n"
    "The bases folder is required, download the whole builder folder."
)
