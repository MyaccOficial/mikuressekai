#!/bin/sh
cd "$(dirname "$0")"
rm -rf vendor
python3 -m pip uninstall -y rg-converters
python3 -m pip install -U -r requirements.txt
python3 -c "import rg_converters.converters as c; print(c.__file__)"
